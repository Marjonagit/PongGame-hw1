﻿namespace ConsoleAppPongFinalProject
{
    struct PlayerData
    {
        public string Name;
        public int Score;
    }
}